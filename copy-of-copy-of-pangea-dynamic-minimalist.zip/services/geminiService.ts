
import { GoogleGenAI } from "@google/genai";

// Standard implementation for Gemini API service following @google/genai guidelines.
export const getStylingAdvice = async (productName: string, prompt?: string) => {
  try {
    // Initialize GoogleGenAI with the API key from environment variables.
    // The key is assumed to be pre-configured in the environment.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Using gemini-3-flash-preview for text generation tasks like styling advice.
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Eres el estilista principal de "Pangea", una marca de ropa minimalista de alta gama.
      El usuario está consultando sobre el producto: "${productName}". 
      ${prompt ? `El usuario añade: "${prompt}"` : "Proporciona algunos consejos de estilo para esta pieza."}
      Mantén un tono profesional, sofisticado y conciso en ESPAÑOL. Céntrate en texturas, paletas monocromáticas y siluetas estructurales.`,
      config: {
        temperature: 0.7,
        topP: 0.9,
      }
    });

    // Access the text property directly from the response object as per @google/genai SDK.
    return response.text || "Lo siento, no pude generar una recomendación de estilo en este momento.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "El Estilista IA de Pangea no está disponible temporalmente. Por favor, inténtalo más tarde.";
  }
};
