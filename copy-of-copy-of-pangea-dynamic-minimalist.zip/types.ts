
export type Category = 
  | 'Remeras Personalizadas' 
  | 'Remeras Basicas' 
  | 'Buzos' 
  | 'Tazas' 
  | 'Remeras Oversize' 
  | 'Otros productos';

export interface Product {
  id: string;
  name: string;
  price: number;
  category: Category;
  description: string;
  image: string;
  backImage?: string;
}

export interface SiteSettings {
  logoUrl: string;
  logoFont: string;
  brandName: string;
  city: string;
  workingDays: string;
  workingHours: string;
  instagramUrl: string;
  whatsappNumber: string;
  email: string;
  heroImageUrl: string;
}

export type View = 'home' | 'catalog' | 'product' | 'admin';
