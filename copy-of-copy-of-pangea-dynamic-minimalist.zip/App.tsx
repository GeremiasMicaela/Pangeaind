
import React, { useState, useEffect, useCallback } from 'react';
import { Product, View, SiteSettings, Category } from './types';
import { PRODUCTS as INITIAL_PRODUCTS, CATEGORIES } from './constants';
import { Navbar } from './components/Navbar';
import { ProductCard } from './components/ProductCard';
import { AIStylist } from './components/AIStylist';

const App: React.FC = () => {
  const [view, setView] = useState<View>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [filter, setFilter] = useState<string>('Todos');
  
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('pangea_admin_auth') === 'true';
  });
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [showLoginError, setShowLoginError] = useState(false);
  
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({ category: 'Remeras Basicas' });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('pangea_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const filteredProducts = products.filter(p => filter === 'Todos' || p.category === filter);

  const [settings, setSettings] = useState<SiteSettings>(() => {
    const saved = localStorage.getItem('pangea_settings');
    return saved ? JSON.parse(saved) : {
      logoUrl: '',
      logoFont: 'Playfair Display',
      brandName: 'PANGEA',
      city: 'Buenos Aires, AR',
      workingDays: 'Lunes a Viernes',
      workingHours: '10:00 - 19:00',
      instagramUrl: '',
      whatsappNumber: '',
      email: '',
      heroImageUrl: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?q=80&w=2000&auto=format&fit=crop'
    };
  });

  const extractColorFromImage = useCallback((imageUrl: string) => {
    if (!imageUrl) {
      updateThemeColors('#ffffff');
      return;
    }
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.src = imageUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      canvas.width = 50;
      canvas.height = 50;
      ctx.drawImage(img, 0, 0, 50, 50);
      const data = ctx.getImageData(0, 0, 50, 50).data;
      
      let r = 0, g = 0, b = 0, count = 0;
      for (let i = 0; i < data.length; i += 4) {
        if (data[i] + data[i+1] + data[i+2] > 100) {
          r += data[i];
          g += data[i+1];
          b += data[i+2];
          count++;
        }
      }
      
      if (count === 0) {
        updateThemeColors('#ffffff');
      } else {
        const avgR = Math.round(r / count);
        const avgG = Math.round(g / count);
        const avgB = Math.round(b / count);
        updateThemeColors(`rgb(${avgR}, ${avgG}, ${avgB})`, avgR, avgG, avgB);
      }
    };
  }, []);

  const updateThemeColors = (color: string, r = 255, g = 255, b = 255) => {
    document.documentElement.style.setProperty('--accent-color', color);
    document.documentElement.style.setProperty('--accent-color-rgb', `${r}, ${g}, ${b}`);
    document.documentElement.style.setProperty('--accent-dark', `rgb(${Math.max(0, r-100)}, ${Math.max(0, g-100)}, ${Math.max(0, b-100)})`);
  };

  useEffect(() => {
    extractColorFromImage(settings.logoUrl);
  }, [settings.logoUrl, extractColorFromImage]);

  useEffect(() => {
    localStorage.setItem('pangea_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('pangea_settings', JSON.stringify(settings));
  }, [settings]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, field: 'logoUrl' | 'heroImageUrl' | 'productImage' | 'backImage') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        if (field === 'logoUrl' || field === 'heroImageUrl') {
          setSettings(prev => ({ ...prev, [field]: base64 }));
        } else if (field === 'productImage') {
          if (editingProduct) setEditingProduct({ ...editingProduct, image: base64 });
          else setNewProduct({ ...newProduct, image: base64 });
        } else if (field === 'backImage') {
          if (editingProduct) setEditingProduct({ ...editingProduct, backImage: base64 });
          else setNewProduct({ ...newProduct, backImage: base64 });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const addProduct = (p: Product) => setProducts([...products, p]);
  const deleteProduct = (id: string) => setProducts(products.filter(p => p.id !== id));
  const updateProduct = (updated: Product) => setProducts(products.map(p => p.id === updated.id ? updated : p));

  const resetAdminForm = () => {
    setNewProduct({ category: 'Remeras Basicas' });
    setEditingProduct(null);
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPasswordInput === 'gereymica') {
      setIsAdminAuthenticated(true);
      sessionStorage.setItem('pangea_admin_auth', 'true');
      setShowLoginError(false);
      setAdminPasswordInput('');
    } else {
      setShowLoginError(true);
    }
  };

  const handleLogout = () => {
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem('pangea_admin_auth');
    setView('home');
    window.scrollTo(0, 0);
  };

  const renderBrandHeader = () => (
    <div className="flex flex-col items-center justify-center pt-32 pb-8 md:pb-12 gap-6 md:gap-8 bg-black transition-theme">
      <div 
        className="h-24 w-24 md:h-32 md:w-32 relative bg-neutral-900 rounded-3xl overflow-hidden border-2 border-accent-soft flex items-center justify-center shadow-2xl cursor-pointer hover:scale-105 transition-all duration-500 btn-focus"
        onClick={() => { setView('home'); window.scrollTo(0,0); }}
      >
        {settings.logoUrl ? (
          <img src={settings.logoUrl} alt="Logo" className="w-full h-full object-cover" />
        ) : (
          <div className="absolute inset-0 flex flex-col opacity-50">
            <div className="h-1/3 w-full bg-[#6a90a4]"></div>
            <div className="h-1/3 w-full bg-[#e8a424]"></div>
            <div className="h-1/3 w-full bg-[#a85032]"></div>
          </div>
        )}
        {!settings.logoUrl && <span className="relative z-10 text-white font-serif text-5xl md:text-6xl font-bold italic -mt-2 drop-shadow-2xl">p</span>}
      </div>
      <h1 
        className="text-4xl sm:text-6xl md:text-8xl font-black uppercase cursor-pointer italic tracking-tighter text-center px-4 transition-theme"
        style={{ fontFamily: settings.logoFont }}
        onClick={() => { setView('home'); window.scrollTo(0,0); }}
      >
        {settings.brandName}
      </h1>
      <div className="w-20 md:w-24 h-1 bg-accent rounded-full transition-theme opacity-50"></div>
    </div>
  );

  const renderHome = () => (
    <div className="relative min-h-screen bg-black transition-theme">
      {renderBrandHeader()}
      <div className="relative h-[50vh] md:h-[65vh] w-full mt-4 md:mt-8 px-4">
        <div className="h-full w-full rounded-[30px] md:rounded-[60px] overflow-hidden relative border border-accent-soft shadow-2xl transition-theme">
          <img 
            src={settings.heroImageUrl} 
            alt="Hero" 
            className="absolute inset-0 w-full h-full object-cover opacity-60 grayscale hover:grayscale-0 transition-all duration-1000"
          />
          <div className="absolute inset-0 flex items-center justify-center text-center p-6 md:p-8 bg-gradient-to-t from-black via-black/20 to-transparent">
            <div className="max-w-3xl animate-in slide-in-from-bottom duration-1000">
              <p className="text-2xl sm:text-3xl md:text-4xl font-serif italic mb-8 md:mb-12 leading-relaxed text-white drop-shadow-lg">
                Minimalismo puro para el día a día.
              </p>
              <button 
                onClick={() => setView('catalog')}
                className="bg-accent text-black px-12 md:px-20 py-5 md:py-7 rounded-[20px] md:rounded-[30px] text-xl sm:text-2xl md:text-3xl font-black shadow-2xl hover:scale-105 active:scale-95 transition-theme uppercase tracking-tighter"
              >
                Explorar Catálogo
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="py-24 md:py-40 px-4 md:px-12 max-w-7xl mx-auto">
         <div className="flex justify-between items-end mb-12 md:mb-20 border-b border-accent-soft pb-6 md:pb-8 transition-theme">
            <div>
              <span className="text-neutral-600 font-black uppercase tracking-[0.4em] text-[10px] md:text-xs">Curated Selection</span>
              <h2 className="text-4xl md:text-6xl font-serif font-black italic mt-2">Destacados</h2>
            </div>
         </div>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
            {products.slice(0, 4).map(product => (
              <ProductCard key={product.id} product={product} onSelect={(p) => { setSelectedProduct(p); setView('product'); window.scrollTo(0,0); }} />
            ))}
         </div>
      </div>
      
      <section className="bg-neutral-900/20 py-16 md:py-24 border-t border-accent-soft transition-theme">
        <AIStylist />
      </section>
    </div>
  );

  const renderCatalog = () => (
    <div className="bg-black min-h-screen transition-theme">
      {renderBrandHeader()}
      <div className="pb-24 md:pb-40 px-4 md:px-12 max-w-7xl mx-auto">
        <div className="sticky top-24 z-40 bg-black/95 backdrop-blur-xl py-6 md:py-10 mb-12 md:mb-20 border-b border-accent-soft transition-theme">
          <div className="flex flex-nowrap md:flex-wrap gap-3 md:gap-4 overflow-x-auto no-scrollbar pb-4 md:pb-0 justify-start md:justify-center">
            {CATEGORIES.map(cat => (
              <button 
                key={cat}
                onClick={() => setFilter(cat)}
                className={`flex-shrink-0 px-6 md:px-10 py-3 md:py-5 rounded-[15px] md:rounded-[25px] text-base md:text-xl font-black transition-theme border-2 ${filter === cat ? 'bg-accent text-black border-accent' : 'border-accent-soft text-neutral-500 hover:border-accent hover:text-white'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-16">
          {filteredProducts.map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onSelect={(p) => { setSelectedProduct(p); setView('product'); window.scrollTo(0,0); }}
            />
          ))}
        </div>
      </div>
    </div>
  );

  const renderProduct = () => {
    if (!selectedProduct) return null;
    return (
      <div className="min-h-screen bg-black transition-theme">
        {renderBrandHeader()}
        <div className="pb-20 lg:pb-40 px-4 md:px-12 max-w-6xl mx-auto animate-in slide-in-from-right duration-500">
          <button 
            onClick={() => setView('catalog')}
            className="mb-8 md:mb-16 flex items-center gap-4 md:gap-6 text-base md:text-xl font-black text-neutral-500 hover:text-accent transition-theme btn-focus p-2 rounded-xl"
          >
            ← VOLVER
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-start">
            <div className="space-y-8 md:space-y-12">
              <div className="rounded-[30px] md:rounded-[60px] overflow-hidden shadow-2xl border border-accent-soft transition-theme aspect-[3/4]">
                <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-full object-cover" />
              </div>
              {selectedProduct.backImage && (
                <div className="rounded-[30px] md:rounded-[60px] overflow-hidden shadow-2xl border border-accent-soft opacity-80 hover:opacity-100 transition-theme aspect-[3/4]">
                  <img src={selectedProduct.backImage} alt="Back" className="w-full h-full object-cover" />
                </div>
              )}
            </div>
            
            <div className="lg:sticky lg:top-36 space-y-8 md:space-y-12">
              <div className="space-y-4">
                <span className="text-accent font-black uppercase tracking-[0.4em] text-xs md:text-sm transition-theme">{selectedProduct.category}</span>
                <h1 className="text-4xl sm:text-5xl md:text-7xl font-serif font-black italic mb-4 leading-tight md:leading-[1] uppercase">{selectedProduct.name}</h1>
                <p className="text-3xl sm:text-4xl md:text-6xl font-black text-white">${selectedProduct.price.toLocaleString()}</p>
              </div>
              
              <div className="w-32 md:w-40 h-2 md:h-3 bg-accent rounded-full transition-theme"></div>
              
              <div className="space-y-6">
                <p className="text-neutral-400 text-lg sm:text-xl md:text-3xl leading-relaxed font-medium italic">
                  "{selectedProduct.description}"
                </p>
              </div>
              
              <div className="pt-8">
                <button 
                  onClick={() => {
                    const message = encodeURIComponent(`¡Hola! Quisiera consultar por el producto: ${selectedProduct.name}`);
                    window.open(`https://wa.me/${settings.whatsappNumber.replace(/\D/g, '')}?text=${message}`, '_blank');
                  }}
                  className="w-full bg-accent text-black py-6 md:py-8 rounded-[25px] md:rounded-[40px] text-xl sm:text-2xl md:text-3xl font-black shadow-2xl hover:scale-[1.02] active:scale-95 transition-theme uppercase tracking-tighter"
                >
                  Consultar WhatsApp
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderAdminPanel = () => (
    <div className="max-w-6xl mx-auto px-4 md:px-6 py-12 space-y-16 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 border-b border-white/10 pb-10 text-center md:text-left">
        <div>
          <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter">Panel Maestro</h2>
          <p className="text-neutral-500 font-bold mt-2 uppercase tracking-widest text-xs md:text-sm">El diseño de la web se adaptará a los colores de tu logo.</p>
        </div>
        <button 
          onClick={handleLogout}
          className="w-full md:w-auto px-10 py-4 bg-red-950/20 text-red-500 border border-red-500/30 rounded-2xl font-black uppercase text-sm hover:bg-red-500 transition-all"
        >
          Cerrar Sesión
        </button>
      </div>

      <section className="bg-neutral-900/50 p-6 md:p-10 rounded-[30px] md:rounded-[40px] border border-accent-soft backdrop-blur-sm transition-theme">
        <h2 className="text-2xl md:text-3xl font-black mb-10 uppercase tracking-tighter flex items-center gap-4">
          <span className="w-8 h-8 bg-accent text-black rounded-full flex items-center justify-center text-sm italic transition-theme">1</span>
          Identidad Visual y Marca
        </h2>
        <div className="grid md:grid-cols-2 gap-10 md:gap-12">
          <div className="space-y-8">
            <label className="block">
              <span className="block text-xs font-black text-neutral-500 mb-3 uppercase tracking-widest">Nombre de la Marca</span>
              <input 
                type="text" 
                value={settings.brandName}
                onChange={(e) => setSettings({...settings, brandName: e.target.value})}
                className="w-full bg-black border-2 border-accent-soft rounded-2xl p-5 text-lg md:text-xl outline-none focus:border-accent transition-theme"
              />
            </label>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-3 text-center">
                <span className="block text-xs font-black text-neutral-500 uppercase tracking-widest">Logo</span>
                <div className="relative group">
                   <div className="w-full h-24 md:h-32 bg-black border-2 border-accent-soft rounded-2xl flex items-center justify-center overflow-hidden transition-theme">
                      {settings.logoUrl ? (
                        <img src={settings.logoUrl} className="w-full h-full object-contain" />
                      ) : (
                        <span className="text-neutral-700 font-bold uppercase text-[10px]">Sin logo</span>
                      )}
                   </div>
                   <label className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity rounded-2xl">
                      <span className="text-white font-bold uppercase text-[10px]">Cambiar</span>
                      <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, 'logoUrl')} />
                   </label>
                </div>
              </div>
              <div className="space-y-3 text-center">
                <span className="block text-xs font-black text-neutral-500 uppercase tracking-widest">Portada</span>
                <div className="relative group">
                   <div className="w-full h-24 md:h-32 bg-black border-2 border-accent-soft rounded-2xl flex items-center justify-center overflow-hidden transition-theme">
                      <img src={settings.heroImageUrl} className="w-full h-full object-cover" />
                   </div>
                   <label className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity rounded-2xl">
                      <span className="text-white font-bold uppercase text-[10px]">Cambiar</span>
                      <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, 'heroImageUrl')} />
                   </label>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
               <label className="block">
                  <span className="block text-xs font-black text-neutral-500 mb-3 uppercase tracking-widest">Ciudad</span>
                  <input 
                    type="text" 
                    value={settings.city}
                    onChange={(e) => setSettings({...settings, city: e.target.value})}
                    className="w-full bg-black border-2 border-accent-soft rounded-2xl p-5 text-lg outline-none focus:border-accent transition-theme"
                  />
                </label>
                <label className="block">
                  <span className="block text-xs font-black text-neutral-500 mb-3 uppercase tracking-widest">WhatsApp</span>
                  <input 
                    type="text" 
                    value={settings.whatsappNumber}
                    onChange={(e) => setSettings({...settings, whatsappNumber: e.target.value})}
                    className="w-full bg-black border-2 border-accent-soft rounded-2xl p-5 text-lg outline-none focus:border-accent transition-theme"
                  />
                </label>
            </div>
          </div>
        </div>
      </section>
    </div>
  );

  const renderLoginForm = () => (
    <div className="max-w-md mx-auto px-6 py-24 text-center">
      <h2 className="text-5xl font-serif font-bold mb-4 italic transition-theme">Maestro</h2>
      <form onSubmit={handleAdminLogin} className="space-y-8 mt-12">
        <input 
          type="password" 
          value={adminPasswordInput}
          onChange={(e) => setAdminPasswordInput(e.target.value)}
          placeholder="Clave de Acceso"
          className="w-full bg-neutral-900 border-2 border-accent-soft rounded-3xl p-6 text-2xl text-center focus:border-accent transition-theme outline-none"
        />
        <button type="submit" className="w-full bg-accent text-black py-6 rounded-3xl text-2xl font-black shadow-xl transition-theme">
          INGRESAR
        </button>
      </form>
    </div>
  );

  return (
    <div className="min-h-screen selection:bg-accent selection:text-black transition-theme">
      <Navbar currentView={view} setView={(v) => { setView(v); window.scrollTo(0,0); }} settings={settings} />

      <main>
        {view === 'home' && renderHome()}
        {view === 'catalog' && renderCatalog()}
        {view === 'product' && renderProduct()}
        {view === 'admin' && (
          <div className="bg-black min-h-screen">
            {renderBrandHeader()}
            {isAdminAuthenticated ? renderAdminPanel() : renderLoginForm()}
          </div>
        )}
      </main>

      <footer className="bg-neutral-950 border-t border-accent-soft py-24 md:py-40 px-6 text-center transition-theme">
        <div className="max-w-5xl mx-auto">
          <div className="text-5xl md:text-7xl font-serif font-black italic mb-16 md:mb-20 tracking-tighter cursor-pointer text-accent transition-theme" style={{ fontFamily: settings.logoFont }} onClick={() => setView('home')}>
            {settings.brandName}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16 md:gap-24 text-xl mb-24 md:mb-32">
            <div className="space-y-6 md:space-y-8">
              <h5 className="font-black text-white uppercase text-[10px] tracking-[0.4em] opacity-40">Shop</h5>
              <button onClick={() => setView('home')} className="block w-full text-neutral-500 hover:text-accent transition-theme uppercase tracking-widest text-xs md:text-sm">Inicio</button>
              <button onClick={() => setView('catalog')} className="block w-full text-neutral-500 hover:text-accent transition-theme uppercase tracking-widest text-xs md:text-sm">Colección</button>
            </div>
            <div className="space-y-6 md:space-y-8">
              <h5 className="font-black text-white uppercase text-[10px] tracking-[0.4em] opacity-40">Redes</h5>
              <a href={`https://instagram.com/${settings.instagramUrl}`} target="_blank" className="block w-full text-neutral-500 hover:text-accent transition-theme uppercase tracking-widest text-xs md:text-sm italic">Instagram</a>
              <button onClick={() => setView('admin')} className="block w-full text-neutral-900 hover:text-accent transition-theme uppercase text-[10px] tracking-[0.5em] pt-6 font-black">Acceso Admin</button>
            </div>
            <div className="space-y-6 md:space-y-8">
              <h5 className="font-black text-white uppercase text-[10px] tracking-[0.4em] opacity-40">Ubicación</h5>
              <p className="text-neutral-500 text-[10px] md:text-sm uppercase tracking-widest">{settings.city}</p>
              <p className="text-neutral-500 text-[10px] md:text-sm uppercase tracking-widest">{settings.workingDays} / {settings.workingHours}</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
