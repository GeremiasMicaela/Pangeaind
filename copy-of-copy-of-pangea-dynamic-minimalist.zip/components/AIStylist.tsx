
import React, { useState } from 'react';
import { getStylingAdvice } from '../services/geminiService';
import { PRODUCTS } from '../constants';

export const AIStylist: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState(PRODUCTS[0].name);
  const [userInput, setUserInput] = useState('');
  const [advice, setAdvice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGetAdvice = async () => {
    if (!userInput.trim() && !loading) {
       // Opcional: feedback si está vacío
    }
    setLoading(true);
    const result = await getStylingAdvice(selectedProduct, userInput);
    setAdvice(result);
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-serif font-bold mb-6">¿Cómo combinar tu ropa?</h2>
        <p className="text-neutral-400 text-xl max-w-2xl mx-auto leading-relaxed">
          Nuestra inteligencia te ayuda a elegir el mejor conjunto para cualquier ocasión. Es muy fácil de usar.
        </p>
      </div>

      <div className="bg-neutral-900/40 border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl">
        <div className="grid md:grid-cols-1 gap-10">
          <div className="space-y-10">
            <div>
              <label className="block text-xl font-bold mb-4">1. Elige una prenda</label>
              <select 
                value={selectedProduct}
                onChange={(e) => setSelectedProduct(e.target.value)}
                className="w-full bg-neutral-900 border-2 border-white/20 rounded-2xl p-5 text-xl font-medium focus:border-white outline-none transition-all cursor-pointer"
              >
                {PRODUCTS.map(p => (
                  <option key={p.id} value={p.name}>{p.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xl font-bold mb-4">2. ¿Para qué ocasión es?</label>
              <textarea 
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder="Ejemplo: Para un cumpleaños, una cena familiar o para ir a caminar..."
                className="w-full bg-neutral-900 border-2 border-white/20 rounded-2xl p-6 text-xl h-44 focus:border-white outline-none transition-all resize-none"
              />
            </div>

            <button 
              onClick={handleGetAdvice}
              disabled={loading}
              className={`w-full py-6 rounded-2xl text-2xl font-black transition-all shadow-xl btn-focus ${
                loading ? 'bg-neutral-800 text-neutral-500 cursor-wait' : 'bg-white text-black hover:scale-[1.02]'
              }`}
            >
              {loading ? 'Pensando consejos...' : 'OBTENER CONSEJOS'}
            </button>
          </div>

          <div className={`mt-12 p-8 rounded-3xl transition-all duration-500 border-2 ${advice ? 'bg-white text-black border-transparent' : 'bg-neutral-900 border-white/5'}`}>
            <h3 className={`text-sm font-black uppercase tracking-[0.2em] mb-6 ${advice ? 'text-black/60' : 'text-neutral-500'}`}>
              Respuesta del Estilista:
            </h3>
            
            {loading ? (
              <div className="space-y-4 animate-pulse">
                <div className="h-6 bg-neutral-800 rounded w-3/4"></div>
                <div className="h-6 bg-neutral-800 rounded w-full"></div>
                <div className="h-6 bg-neutral-800 rounded w-5/6"></div>
              </div>
            ) : advice ? (
              <div className="text-xl leading-relaxed font-medium">
                {advice}
              </div>
            ) : (
              <div className="text-neutral-600 italic text-xl">
                Escribe algo arriba y presiona el botón para recibir ayuda.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
