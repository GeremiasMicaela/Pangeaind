
import React, { useState } from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const [showBack, setShowBack] = useState(false);

  return (
    <div 
      className="bg-neutral-950 rounded-[40px] overflow-hidden border border-accent-soft shadow-xl group hover:border-accent transition-theme cursor-pointer" 
      onClick={() => onSelect(product)}
    >
      <div className="aspect-[3/4] relative overflow-hidden bg-neutral-900">
        <img 
          src={showBack && product.backImage ? product.backImage : product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-all duration-700 group-hover:scale-105"
        />
        
        {product.backImage && (
          <button 
            onClick={(e) => { e.stopPropagation(); setShowBack(!showBack); }}
            className="absolute bottom-6 right-6 bg-black/40 backdrop-blur-xl border border-accent-soft px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] hover:bg-accent hover:text-black transition-theme"
          >
            {showBack ? 'Frente' : 'Dorso'}
          </button>
        )}
      </div>
      
      <div className="p-10">
        <div className="mb-4">
           <p className="text-accent text-[10px] font-black uppercase tracking-[0.4em] mb-2 transition-theme">
            {product.category}
          </p>
          <h3 className="text-3xl font-serif font-black italic text-white line-clamp-1 group-hover:text-accent transition-theme">{product.name}</h3>
        </div>
        
        <div className="flex justify-between items-center mt-8">
          <span className="text-2xl font-black text-neutral-400 transition-theme">${product.price.toLocaleString()}</span>
          <div className="w-12 h-12 bg-accent-soft rounded-full flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-black transition-theme">
            →
          </div>
        </div>
      </div>
    </div>
  );
};
