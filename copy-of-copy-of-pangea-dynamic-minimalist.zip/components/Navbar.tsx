
import React from 'react';
import { View, SiteSettings } from '../types';

interface NavbarProps {
  currentView: View;
  setView: (view: View) => void;
  settings: SiteSettings;
}

export const Navbar: React.FC<NavbarProps> = ({ setView, currentView, settings }) => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black border-b border-white/20 h-24 flex items-center px-4 md:px-12 justify-between">
      <button 
        className="flex items-center gap-4 cursor-pointer hover:opacity-80 transition-all p-2 rounded-lg btn-focus"
        onClick={() => setView('home')}
        aria-label="Ir al inicio"
      >
        <div className="h-12 w-12 relative bg-neutral-900 rounded-lg overflow-hidden border border-white/20 flex items-center justify-center">
          {settings.logoUrl ? (
            <img src={settings.logoUrl} alt="Logo" className="w-full h-full object-cover" />
          ) : (
            <div className="absolute inset-0 flex flex-col">
              <div className="h-1/3 w-full bg-[#6a90a4]"></div>
              <div className="h-1/3 w-full bg-[#e8a424]"></div>
              <div className="h-1/3 w-full bg-[#a85032]"></div>
            </div>
          )}
          {!settings.logoUrl && <span className="relative z-10 text-white font-serif text-3xl font-bold italic drop-shadow-lg">p</span>}
        </div>
        <span 
          className="text-2xl font-bold tracking-tight hidden sm:block uppercase"
          style={{ fontFamily: settings.logoFont }}
        >
          {settings.brandName}
        </span>
      </button>

      <div className="flex gap-4 md:gap-8">
        <button 
          onClick={() => setView('home')} 
          className={`px-4 py-2 text-lg font-bold rounded-md transition-all btn-focus ${currentView === 'home' ? 'bg-white text-black' : 'text-white hover:bg-white/10'}`}
        >
          Inicio
        </button>
        <button 
          onClick={() => setView('catalog')} 
          className={`px-4 py-2 text-lg font-bold rounded-md transition-all btn-focus ${currentView === 'catalog' ? 'bg-white text-black' : 'text-white hover:bg-white/10'}`}
        >
          Catálogo
        </button>
      </div>
    </nav>
  );
};
