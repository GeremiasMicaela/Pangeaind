
import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Remera Signature Custom',
    price: 35000,
    category: 'Remeras Personalizadas',
    description: 'Tus ideas, nuestra calidad. Algodón premium con impresión DTG de alta definición y durabilidad garantizada.',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=800&auto=format&fit=crop',
    backImage: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '2',
    name: 'Essential Black Core',
    price: 25000,
    category: 'Remeras Basicas',
    description: 'La base de cualquier outfit. Calce regular, 100% algodón peinado de tacto suave.',
    image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=800&auto=format&fit=crop',
    backImage: 'https://images.unsplash.com/photo-1562157873-818bc0726f68?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '3',
    name: 'Hoodie Charcoal Heavy',
    price: 65000,
    category: 'Buzos',
    description: 'Estructura pesada y calidez máxima. El buzo definitivo con terminaciones reforzadas.',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=800&auto=format&fit=crop',
    backImage: 'https://images.unsplash.com/photo-1556821840-d16455589393?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '4',
    name: 'Remera Boxy Urban',
    price: 40000,
    category: 'Remeras Oversize',
    description: 'Silueta contemporánea y relajada. Hombros caídos y tela de alto gramaje para un look estructurado.',
    image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=800&auto=format&fit=crop',
    backImage: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '5',
    name: 'Graphic Noir Edición Especial',
    price: 38000,
    category: 'Remeras Personalizadas',
    description: 'Diseño de autor con estética monocromática. Calidad de exportación y calce perfecto.',
    image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=800&auto=format&fit=crop',
    backImage: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '6',
    name: 'Dusty Rose Premium',
    price: 42000,
    category: 'Remeras Oversize',
    description: 'El equilibrio perfecto entre comodidad y vanguardia. Tinte reactivo que no pierde color.',
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=800&auto=format&fit=crop',
    backImage: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '7',
    name: 'Taza Void Ceramic',
    price: 12000,
    category: 'Tazas',
    description: 'Minimalismo en tu escritorio. Cerámica mate con acabado industrial y diseño ergonómico.',
    image: 'https://images.unsplash.com/photo-1517142089942-ba376ce32a2e?q=80&w=800&auto=format&fit=crop',
    backImage: 'https://images.unsplash.com/photo-1520970014086-2208d157c9e2?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: '8',
    name: 'Pangea Archive Tote',
    price: 18000,
    category: 'Otros productos',
    description: 'Lona de alta resistencia para llevar tu mundo minimalista a todos lados. Costuras reforzadas.',
    image: 'https://images.unsplash.com/photo-1544816153-12ad5d714481?q=80&w=800&auto=format&fit=crop',
    backImage: 'https://images.unsplash.com/photo-1544816153-12ad5d714481?q=80&w=800&auto=format&fit=crop'
  }
];

export const CATEGORIES: string[] = [
  'Todos',
  'Remeras Personalizadas',
  'Remeras Basicas',
  'Buzos',
  'Tazas',
  'Remeras Oversize',
  'Otros productos'
];
